self.assetsManifest = {
  "version": "tJomnQn/",
  "assets": [
    {
      "hash": "sha256-G8nE3nHyEnViLPoqh/04rv8vHawGLQCasRY6eSvOOGA=",
      "url": "SampleApp.styles.css"
    },
    {
      "hash": "sha256-/PbvE6qnnEDO3aL/UsN1rdRqu86udyP8e55jCA8jTgI=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ca5xgge1r2.wasm"
    },
    {
      "hash": "sha256-JmnBR4DcINen5czBo7dWB5Wil0VAtvxF2gFSwXW5Lc0=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.26c9tx9k9t.wasm"
    },
    {
      "hash": "sha256-MIQAkbwY/9gy+/CnG3UtpUeWNyRMn26RmdDEMeIz3KU=",
      "url": "_framework/Microsoft.AspNetCore.Components.wcqz4sq856.wasm"
    },
    {
      "hash": "sha256-3ADlF4CLU1Q+dQbj0MnPVnEJPiA4q4Jv5xxmiGEvBks=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.85u9862gz3.wasm"
    },
    {
      "hash": "sha256-kKMubKJ3c2lATxpoAuoDqMjzQ+a0M6Ym35pK74cMK2o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.0cm6d8ej68.wasm"
    },
    {
      "hash": "sha256-fN4AyqImDQ+h3H7tFeF4ZSkjIHJ7qWgbKL217x6P53s=",
      "url": "_framework/Microsoft.Extensions.Configuration.cyz6aj3end.wasm"
    },
    {
      "hash": "sha256-UKpLgubIOAmn/oPTHaop+Ppw0ZUyarHjxoPCCBBBQWs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.04io4cndlx.wasm"
    },
    {
      "hash": "sha256-Sgs1bgmGaF2mv6rWcaihc+x48ZQQAidfzYwZvYX5WJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.uum8fsrbn4.wasm"
    },
    {
      "hash": "sha256-aO9VtQiCfALBUiKSRliDgJ8yiO3sXSupu5+y3hxbWFo=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.os166f6kpj.wasm"
    },
    {
      "hash": "sha256-I/euMiwOKn2U2Y1vqcUjYWEG/7zWmvDiTlHAoPLRHQ0=",
      "url": "_framework/Microsoft.Extensions.Logging.p9svcbtg1a.wasm"
    },
    {
      "hash": "sha256-zb8jFz8oWzH9QDCIv6znwkEZEqBZjRrXTb7biON1h4o=",
      "url": "_framework/Microsoft.Extensions.Options.z0tlm9uxjf.wasm"
    },
    {
      "hash": "sha256-Y7+Ee2DJrdAFIYTnAKXZcv8xVEtfQjGGCP0PknJTWPQ=",
      "url": "_framework/Microsoft.Extensions.Primitives.7n6rlssyfp.wasm"
    },
    {
      "hash": "sha256-ubnFa4Rtxgu4gPe/SRKYk17LxS0CtEOnEoPvT6ITOTo=",
      "url": "_framework/Microsoft.JSInterop.7kva84rxiz.wasm"
    },
    {
      "hash": "sha256-mpyjzA6YBuV9Qx5BUC8YbXP9YjZlM+k7YTVawzXJFgk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.imfqvv3x5h.wasm"
    },
    {
      "hash": "sha256-MhX7FqqOvo2Zqnv7cZ5eAku8rgi9Ybpkz3BWlQCl+U4=",
      "url": "_framework/SampleApp.ynfe8jj17k.wasm"
    },
    {
      "hash": "sha256-P6B9N3fO7t6t5v872YlnIwVE4STt5o+KpUbMJycgBrs=",
      "url": "_framework/System.Collections.Concurrent.hwz06lvarn.wasm"
    },
    {
      "hash": "sha256-LJe+90M/i9ThPbObyIYyiJ46FRsGT8cprbuJqpMnucE=",
      "url": "_framework/System.Collections.Immutable.4ghyol54a5.wasm"
    },
    {
      "hash": "sha256-hri4OMF7KGVk0munKev5ECm3YjePUYCouy7bQOPiTNM=",
      "url": "_framework/System.Collections.eapm7a0zcn.wasm"
    },
    {
      "hash": "sha256-DHujPeYswdt0JOBw03JC11hmqQ+Vtb1K9fkbgtDLtTM=",
      "url": "_framework/System.ComponentModel.0n5errmvx8.wasm"
    },
    {
      "hash": "sha256-m23pRd08wqcxINfeolmq+5fxtnvG4CKsSq3SNKPhMbU=",
      "url": "_framework/System.Console.3mkpt7g2kd.wasm"
    },
    {
      "hash": "sha256-mLiZ2KVL+a+dFuTtYcQVelr78wfU5C42nGthneT4yMw=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.kleeaz9n0e.wasm"
    },
    {
      "hash": "sha256-ltKNH6AL0soduarPfzy6T90WE3rPgr3GhVxWtFvIglk=",
      "url": "_framework/System.IO.Pipelines.mslxeuynkl.wasm"
    },
    {
      "hash": "sha256-X+duWp05ll4ZZm0Az+tKzWOQw5jnp68/cSmrFr9N2XY=",
      "url": "_framework/System.Linq.72pexot6tw.wasm"
    },
    {
      "hash": "sha256-jhhk/aUdoCCrk+I6cBCLD4YTu9Ek9peLsFv4NDwxFYM=",
      "url": "_framework/System.Memory.qmgd6z2we4.wasm"
    },
    {
      "hash": "sha256-5ASg3Zr+p36Lpz8+uDoYkemAf+ptr+wuikD/FdsyjRg=",
      "url": "_framework/System.Net.Http.Json.cc6gva5xqd.wasm"
    },
    {
      "hash": "sha256-ilIRZnREp12c8liYaYYEio9SxBqh5EvJvyEbrM6Hs1s=",
      "url": "_framework/System.Net.Http.aj8lzzud17.wasm"
    },
    {
      "hash": "sha256-DqsumNiS0cF1FXZ5sSRsGHgAG63fChKhelkEA9f6A50=",
      "url": "_framework/System.Net.Primitives.yjcmep7m7h.wasm"
    },
    {
      "hash": "sha256-tLRVvmQGW3DQdivw5/eu+kJ6vtsPFUSxB2MfULPUjqg=",
      "url": "_framework/System.Private.CoreLib.s0fd6ijh7c.wasm"
    },
    {
      "hash": "sha256-ObE2W8ZT2OOvhxcL5o9ArsW//W0chkJ5m6lO7P4bPng=",
      "url": "_framework/System.Private.Uri.ventfxaog2.wasm"
    },
    {
      "hash": "sha256-5X6FWiZE4NSx4s9iNjfVim2lWQpcbVIsorx1vB6lyno=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.f7txb1es0b.wasm"
    },
    {
      "hash": "sha256-1ZI6R9y7Eg/odNK57CwUASBdVSr3LN07fqtYNgeZtBE=",
      "url": "_framework/System.Runtime.b4t3zpn95a.wasm"
    },
    {
      "hash": "sha256-QPumUm/+bRPi/T+QpPMfrlCeezAnzRk6CmD/iBskgiw=",
      "url": "_framework/System.Text.Encodings.Web.08ymq1fvcr.wasm"
    },
    {
      "hash": "sha256-JEIbMnFqfA0kv0ozHkBsW0wWI9Dzcrx+oyFGxnE8dHg=",
      "url": "_framework/System.Text.Json.sikpqtqagt.wasm"
    },
    {
      "hash": "sha256-J0h0LpWzXEYF0E+lUOiWbLF6UobUv3nu0XKBs3nMIoQ=",
      "url": "_framework/System.Text.RegularExpressions.3ddyst6dmo.wasm"
    },
    {
      "hash": "sha256-I/g3ZWSYEwhjlVEE6GcRlrt5SIOKLdgsw/NnzlOIgQA=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-gD2XMSIt+vtDFirTg+LVASuuDVoOW3S7fY2a27Ou3Vs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-RtuwNrUOdAJ5A4aS4ZmceO4ySriaYqTdC7X++6yd9lM=",
      "url": "_framework/dotnet.native.21mns4qp4i.wasm"
    },
    {
      "hash": "sha256-oS7IRiQoVt9ThQ7Y2UM3XoeY0JqPD02cg9IvRdufn2w=",
      "url": "_framework/dotnet.native.9ih887ebfz.js"
    },
    {
      "hash": "sha256-oBRKHAqZUsvCRnCzkQfB7zc45cpKLNq2NKyrG10IKx8=",
      "url": "_framework/dotnet.runtime.st3wwc8rqy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-c4tZCDbu0JnldbnisjREzeU9Z8Gi6tWw+QJjcviGzwk=",
      "url": "index.html"
    },
    {
      "hash": "sha256-7IQ+pBT+HcjaBGLKdUm8otrsGLglsKQqwOdSTrmAqBo=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
